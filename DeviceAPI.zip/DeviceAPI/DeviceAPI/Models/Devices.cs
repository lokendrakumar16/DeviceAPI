﻿using System;
using System.Collections.Generic;

namespace DeviceAPI.Models
{
    public partial class Devices
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
