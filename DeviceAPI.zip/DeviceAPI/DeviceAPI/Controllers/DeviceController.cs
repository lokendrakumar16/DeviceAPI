﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DeviceAPI.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DeviceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DeviceController : ControllerBase
    {

        // Get list of devices
        [HttpGet]
        [Route("getdevice")]
        public IEnumerable<Devices> GetDevicesValues()
        {
            using (var context = new DeviceContext())
            {
                return context.Devices.ToList();
            }
        }

        // Save a device
        [HttpPost]
        [Route("savedevice")]
        public IActionResult AddDevice([FromBody] Devices device)
        {
            if (ModelState.IsValid)
            {
                using (var context = new DeviceContext())
                {
                    context.Devices.Add(device);
                    context.SaveChanges();
                }
            }
            return StatusCode(200, "Device inserted.");
        }

        // Filtering on devices
        [HttpGet]
        [Route("filter/{device}/{type}/{value}")]
        public IEnumerable<Devices> FilterDevicesValues(string device, string type, int value)
        {
            using (var context = new DeviceContext())
            {
                var res =  context.Devices.Where(d => d.Name == device).ToList();

                foreach (var item in res)
                {
                    foreach (var it in item.Value)
                    {
                        if (it.ToString() != ",")
                        {
                            if (Int32.Parse(it.ToString()) > value)
                            {
                                var a = String.Concat(it);
                            }
                        }
                        
                    }
                }
                return res;
            }
        }
    }
}
